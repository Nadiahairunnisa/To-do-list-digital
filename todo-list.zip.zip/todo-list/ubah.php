<?php require_once('Connections/koneksi.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['kd_jadwal'])) && ($_GET['kd_jadwal'] != "")) {
  $deleteSQL = sprintf("DELETE FROM jadwal WHERE kd_jadwal=%s",
                       GetSQLValueString($_GET['kd_jadwal'], "text"));

  mysql_select_db($database_koneksi, $koneksi);
  $Result1 = mysql_query($deleteSQL, $koneksi) or die(mysql_error());

  $deleteGoTo = "administrator.php?kd_jadwal=" . $row_hapus['kd_jadwal'] . "";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form2")) {
  $updateSQL = sprintf("UPDATE jadwal SET hari=%s, tanggal=%s, pukul=%s, kegiatan=%s, keterangan=%s WHERE kd_jadwal=%s",
                       GetSQLValueString($_POST['hari'], "text"),
                       GetSQLValueString($_POST['tanggal'], "date"),
                       GetSQLValueString($_POST['pukul'], "date"),
                       GetSQLValueString($_POST['kegiatan'], "text"),
                       GetSQLValueString($_POST['keterangan'], "text"),
                       GetSQLValueString($_POST['kd_jadwal'], "text"));

  mysql_select_db($database_koneksi, $koneksi);
  $Result1 = mysql_query($updateSQL, $koneksi) or die(mysql_error());

  $updateGoTo = "administrator.php?kd_jadwal=" . $row_ubah['kd_jadwal'] . "";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_hapus = "-1";
if (isset($_GET['kd_jadwal'])) {
  $colname_hapus = $_GET['kd_jadwal'];
}
mysql_select_db($database_koneksi, $koneksi);
$query_hapus = sprintf("SELECT * FROM jadwal WHERE kd_jadwal = %s", GetSQLValueString($colname_hapus, "text"));
$hapus = mysql_query($query_hapus, $koneksi) or die(mysql_error());
$row_hapus = mysql_fetch_assoc($hapus);
$totalRows_hapus = mysql_num_rows($hapus);

$colname_ubah = "-1";
if (isset($_GET['kd_jadwal'])) {
  $colname_ubah = $_GET['kd_jadwal'];
}
mysql_select_db($database_koneksi, $koneksi);
$query_ubah = sprintf("SELECT * FROM jadwal WHERE kd_jadwal = %s", GetSQLValueString($colname_ubah, "text"));
$ubah = mysql_query($query_ubah, $koneksi) or die(mysql_error());
$row_ubah = mysql_fetch_assoc($ubah);
$totalRows_ubah = mysql_num_rows($ubah);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
</form>
<form action="<?php echo $editFormAction; ?>" method="post" name="form2" id="form2">
  <table align="center">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Kd_jadwal:</td>
      <td><?php echo $row_ubah['kd_jadwal']; ?></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Hari:</td>
      <td><input type="text" name="hari" value="<?php echo htmlentities($row_ubah['hari'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Tanggal:</td>
      <td><input type="text" name="tanggal" value="<?php echo htmlentities($row_ubah['tanggal'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Pukul:</td>
      <td><input type="text" name="pukul" value="<?php echo htmlentities($row_ubah['pukul'], ENT_COMPAT, 'utf-8'); ?>" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right" valign="top">Kegiatan:</td>
      <td><textarea name="kegiatan" cols="50" rows="5"><?php echo htmlentities($row_ubah['kegiatan'], ENT_COMPAT, 'utf-8'); ?></textarea></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">Keterangan:</td>
      <td><select name="keterangan">
        <option value="" >sudah</option>
        <option value="" >belum</option>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><input type="submit" value="Update record" /></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form2" />
  <input type="hidden" name="kd_jadwal" value="<?php echo $row_ubah['kd_jadwal']; ?>" />
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($hapus);

mysql_free_result($ubah);
?>
